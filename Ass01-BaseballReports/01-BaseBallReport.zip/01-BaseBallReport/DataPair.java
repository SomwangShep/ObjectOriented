
public class DataPair {
	private String m_name;
	private int m_stat;

	public DataPair(String m_name, int  m_stat) {
		super();
		this.m_name = m_name;
		this.m_stat = m_stat;
	}

	public String getName()	{	return m_name;	}
	public int getStat()	{	return m_stat;	}

}
