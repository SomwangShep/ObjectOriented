
public interface IEstimatable {
	public double estimate(int sqft);
}
