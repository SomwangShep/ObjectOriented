
public class House implements IEstimatable{

	public double estimate(int sqft)
	{
		return sqft*97;
	}
	
}
