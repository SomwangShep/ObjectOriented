
public interface IGrader {
	public double grade();
}
